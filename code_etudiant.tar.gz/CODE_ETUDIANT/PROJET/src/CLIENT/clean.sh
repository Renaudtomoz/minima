#!/bin/bash

exe="client"

for f in $exe
do
    /bin/rm $f
done

