#!/bin/bash

exe="test_config"

for f in $exe
do
    /bin/rm $f
done

