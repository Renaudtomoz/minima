#!/bin/bash

cd CLIENT
./compil.sh
cd ..

cd ORCHESTRE
./compil.sh
cd ..

cd SERVICE
./compil.sh
cd ..
