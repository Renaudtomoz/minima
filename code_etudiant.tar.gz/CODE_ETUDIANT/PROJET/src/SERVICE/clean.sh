#!/bin/bash

exe="service"

for f in $exe
do
    /bin/rm $f
done

