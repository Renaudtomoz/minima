#ifndef SERVICE_SOMME_H
#define SERVICE_SOMME_H

// on ne déclare ici que les fonctions appelables par le main

// fonction pour gérer la communication avec le client
void service_somme(/* fd des deux tubes nommés avec le client */);

#endif

