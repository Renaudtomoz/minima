#!/bin/bash

cd CLIENT
./clean.sh
cd ..

cd ORCHESTRE
./clean.sh
cd ..

cd SERVICE
./clean.sh
cd ..
