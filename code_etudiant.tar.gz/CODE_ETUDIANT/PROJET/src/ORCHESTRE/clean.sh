#!/bin/bash

exe="orchestre"

for f in $exe
do
    /bin/rm $f
done

